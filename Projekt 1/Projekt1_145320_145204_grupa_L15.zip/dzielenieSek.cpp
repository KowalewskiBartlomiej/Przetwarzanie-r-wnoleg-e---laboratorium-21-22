#include <stdio.h>
#include <vector>
#include <math.h>
#include <algorithm>

#define COMPLEX 0;
#define PRIME 1;
using namespace std;

vector <int> primes = { 2 };

bool primeOrComplex(int number) 
{
	if (find(primes.begin(), primes.end(), number) != primes.end()) 
		return PRIME;

	int upperLimit = floor( sqrt(number) );
	for (int i = 0; ; i++) 
	{
		int divider = primes[i];
		if (upperLimit < divider) 
		{
			return PRIME;
		}
		else if (number % divider == 0) 
		{
			return COMPLEX;
		}
		else if (primes.size() - 1 == i) 
		{
			int nextPrimeNumber;
			for (nextPrimeNumber = primes.back() + 1; !primeOrComplex(nextPrimeNumber); nextPrimeNumber++)
			{
				continue;
			}
			primes.push_back(nextPrimeNumber);
			divider = nextPrimeNumber;
		}
	}
}

vector <int> findPrimeNumbers(int lowerLimit, int upperLimit)
{
	vector <int> foundPrimes;

	for (int testedNumber = lowerLimit; testedNumber <= upperLimit; testedNumber++)
	{
		if (primeOrComplex(testedNumber))
		{
			foundPrimes.push_back(testedNumber);
		}
	}

	return foundPrimes;
}

int main() {
	vector <int> tmp = findPrimeNumbers(2, 100000000);
	for (int i = 0; i < tmp.size(); i++)
		printf("%d ", tmp[i]);
}