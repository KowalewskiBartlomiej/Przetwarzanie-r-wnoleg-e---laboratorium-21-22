﻿#include <stdio.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <omp.h>

#define threadsNum 8

#define PRIME 1
#define COMPLEX 0
using namespace std;


void printResultPrimes(vector <int> primes)
{
    for (int i = 0; i < primes.size(); i++)
    {
        printf("%d ", primes[i]);
        if (i % 10 == 9) 
            printf("\n");
    }
    printf("\nLiczba pierwszych: %ld\n", primes.size());
}

vector<vector<int>> initializeSubsets(int lowerLimit, int upperLimit, int subsetsNumber)
{
    int range = (upperLimit - lowerLimit) / subsetsNumber;
    vector <vector<int>> subsets;
    vector <int> subset;

    int nextNumber = lowerLimit;
    for (int i = 0; i < subsetsNumber - 1; i++)
    {
        subset = { nextNumber, nextNumber + range - 1};
        subsets.push_back(subset);
        nextNumber = nextNumber + range;
    }
    subset = { nextNumber, upperLimit };
    subsets.push_back(subset);

    return subsets;
}


void findStartingPrimes(int min, int max, vector<int> &startingPrimes) {

    int lastNum = (int)sqrt(max);
    vector<bool> isPrime2;
    for (int i = 2; i <= max; i++)
        isPrime2.push_back(PRIME);

    for (int divider = 2; divider <= lastNum; divider++)
    {
        if (isPrime2[divider - 2] == COMPLEX)
            continue;

        for (int multiple = divider + divider; multiple <= max; multiple += divider) 
            isPrime2[multiple - 2] = COMPLEX;
    }

    for (int i = min - 2; i < isPrime2.size(); i++)
    {
        if (isPrime2[i] == PRIME)
            startingPrimes.push_back(i + 2);
    }
}

void findPrimesDomain(int minNum, int maxNum, vector<int> &primes)
{
    vector < vector <int> > subsets = initializeSubsets(minNum, maxNum, threadsNum);
    int lastNum = (int)sqrt(maxNum);
    vector <int> startingPrimes;
    findStartingPrimes(2, lastNum, startingPrimes);

    vector <bool> subset0;
    vector <bool> subset1;
    vector <bool> subset2;
    vector <bool> subset3;
    vector <bool> subset4;
    vector <bool> subset5;
    vector <bool> subset6;
    vector <bool> subset7;

    #pragma omp	parallel num_threads(threadsNum)
    {
        int threadNumber = omp_get_thread_num();
        vector<int> privateSubset = subsets[threadNumber];
        int lowerSubsetLimit = privateSubset[0];
        int upperSubsetLimit = privateSubset[1];
        int subsetRange = upperSubsetLimit - lowerSubsetLimit + 1;
        
        vector<bool> subset(subsetRange, PRIME);

        for (int i = 0; i < startingPrimes.size(); i++)
        {
            int divider = startingPrimes[i];
            int multiple = lowerSubsetLimit;
            for (; multiple % divider != 0; multiple++)
                continue;
            if (multiple == divider)
                multiple = divider + divider;

            for (; multiple <= upperSubsetLimit; multiple += divider) 
                subset[multiple - lowerSubsetLimit] = COMPLEX;
        }

        switch (threadNumber)
        {
        case 0:
            subset0 = subset;
            break;
        case 1:
            subset1 = subset;
            break;
        case 2:
            subset2 = subset;
            break;
        case 3:
            subset3 = subset;
            break;
        case 4:
            subset4 = subset;
            break;
        case 5:
            subset5 = subset;
            break;
        case 6:
            subset6 = subset;
            break;
        case 7:
            subset7 = subset;
            break;
        }
    }

    vector<bool> isPrime(minNum, COMPLEX);
    //isPrime.reserve(maxNum - minNum);

    
    if (threadsNum == 0)
        goto isPrimeCreated;
    isPrime.insert(isPrime.end(), subset0.begin(), subset0.end());
    
    
    if (threadsNum == 1)
        goto isPrimeCreated;
    isPrime.insert(isPrime.end(), subset1.begin(), subset1.end());
    
    
    if (threadsNum == 2)
        goto isPrimeCreated;
    isPrime.insert(isPrime.end(), subset2.begin(), subset2.end());
    
    
    if (threadsNum == 3)
        goto isPrimeCreated;
    isPrime.insert(isPrime.end(), subset3.begin(), subset3.end());
    
    
    if (threadsNum == 4)
        goto isPrimeCreated;
    isPrime.insert(isPrime.end(), subset4.begin(), subset4.end());
    
    
    if (threadsNum == 5)
        goto isPrimeCreated;
    isPrime.insert(isPrime.end(), subset5.begin(), subset5.end());
    
    
    if (threadsNum == 6)
        goto isPrimeCreated;
    isPrime.insert(isPrime.end(), subset6.begin(), subset6.end());
    
    
    if (threadsNum == 7)
        goto isPrimeCreated;
    isPrime.insert(isPrime.end(), subset7.begin(), subset7.end());
    

isPrimeCreated:
    for (int i = minNum - 2; i < isPrime.size(); i++)
    {
        if (isPrime[i] == PRIME)
            primes.push_back(i);
    }
}

int main()
{
    vector<int> result;
    findPrimesDomain(2, 200000000, result); 
    printResultPrimes(result);
}
