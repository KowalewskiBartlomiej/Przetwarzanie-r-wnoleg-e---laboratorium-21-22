﻿#include <stdio.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <omp.h>

#define threadsNum 8

#define PRIME 1
#define COMPLEX 0

using namespace std;

void printPrimes(vector <int> primes)
{
    for (int i = 0; i < primes.size(); i++)
    {
        printf("%d ", primes[i]);
        if (i % 10 == 9) 
            printf("\n");
    }
    printf("\nLiczba pierwszych: %ld\n", primes.size());
}


vector<int> findStartingPrimes(int min, int max) {

    int lastNum = (int)sqrt(max);
    vector<bool> isPrime;
    for (int i = 2; i <= max; i++)
        isPrime.push_back(PRIME);

    for (int divider = 2; divider <= lastNum; divider++)
    {
        if (isPrime[divider - 2] == COMPLEX)
            continue;

        for (int multiple = divider + divider; multiple <= max; multiple += divider)
            isPrime[multiple - 2] = COMPLEX;
    }

    vector<int> startingPrimes;
    for (int i = min- 2; i < isPrime.size(); i++)
    {
        if (isPrime[i] == PRIME)
            startingPrimes.push_back(i + 2);
    }

    return startingPrimes;

}

void findPrimesFunctional(int minNum, int maxNum, vector<int> &primes)
{
    int lastNum = (int)sqrt(maxNum);
    int range = (maxNum - minNum) + 1;
    vector <int> startingPrimes;
    startingPrimes = findStartingPrimes(2, lastNum);

    vector <bool> isPrime0;
    vector <bool> isPrime1;
    vector <bool> isPrime2;
    vector <bool> isPrime3;
    vector <bool> isPrime4;
    vector <bool> isPrime5;
    vector <bool> isPrime6;
    vector <bool> isPrime7;

    #pragma omp	parallel num_threads(threadsNum)
    {
        int threadNumber = omp_get_thread_num();
        vector<bool> localIsPrime(range, PRIME);

        #pragma omp	for schedule(dynamic)
        for (int i = 0; i < startingPrimes.size(); i++)
        {
            int divider = startingPrimes[i];
            int multiple = minNum;
            for (; multiple % divider != 0; multiple++)
                continue;
            if (multiple == divider)
                multiple = divider + divider;

            for (; multiple <= maxNum; multiple += divider)
                localIsPrime[multiple - minNum] = COMPLEX;
        }

        switch (threadNumber)
        {
        case 0:
            isPrime0 = localIsPrime;
            break;
        case 1:
            isPrime1 = localIsPrime;
            break;
        case 2:
            isPrime2 = localIsPrime;
            break;
        case 3:
            isPrime3 = localIsPrime;
            break;
        case 4:
            isPrime4 = localIsPrime;
            break;
        case 5:
            isPrime5 = localIsPrime;
            break;
        case 6:
            isPrime6 = localIsPrime;
            break;
        case 7:
            isPrime7 = localIsPrime;
            break;
        }
    }

    vector <bool> isPrime(minNum, COMPLEX);
    switch (threadsNum)
    {
    case 1:
        for (int i = 0; i < range; i++)
            isPrime.push_back(isPrime0[i]);
        break;
    case 2:
        for (int i = 0; i < range; i++)
            isPrime.push_back(
                isPrime0[i] * isPrime1[i]);
        break;
    case 3:
        for (int i = 0; i < range; i++)
            isPrime.push_back(
                isPrime0[i] * isPrime1[i] * isPrime2[i]);
        break;
    case 4:
        for (int i = 0; i < range; i++)
            isPrime.push_back(
                isPrime0[i] * isPrime1[i] * isPrime2[i] * isPrime3[i]);
        break;
    case 5:
        for (int i = 0; i < range; i++)
            isPrime.push_back(
                isPrime0[i] * isPrime1[i] * isPrime2[i] * isPrime3[i] * isPrime4[i]);
        break;
    case 6:
        for (int i = 0; i < range; i++)
            isPrime.push_back(
                isPrime0[i] * isPrime1[i] * isPrime2[i] * isPrime3[i] * isPrime4[i] * isPrime5[i]);
        break;
    case 7:
        for (int i = 0; i < range; i++)
            isPrime.push_back(
                isPrime0[i] * isPrime1[i] * isPrime2[i] * isPrime3[i] * isPrime4[i] * isPrime5[i] * isPrime6[i]);
        break;
    case 8:
        for (int i = 0; i < range; i++)
            isPrime.push_back(
                isPrime0[i] * isPrime1[i] * isPrime2[i] * isPrime3[i] * isPrime4[i] * isPrime5[i] * isPrime6[i] * isPrime7[i]);
        break;
    }

    for (int i = minNum - 2; i < isPrime.size(); i++)
    {
        if (isPrime[i] == PRIME)
            primes.push_back(i);
    }
}


int main()
{
    vector<int> result;
    findPrimesFunctional(2, 100000000, result); 
    printPrimes(result);
}
