#include <stdio.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

#define PRIME 1
#define COMPLEX 0

using namespace std;

void printResultPrimes(vector <int> vec)
{
    for (int i = 0; i < vec.size(); i++)
    {
        printf("%d ", vec[i]);
        if (i % 10 == 9)
            printf("\n");
    }
    printf("\nLiczba pierwszych: %ld\n", vec.size());
}

void eratosthenesSieve(int min, int max, vector<int> &primes) {

    int lastNum = (int)sqrt(max);
    vector<bool> isPrime;
    for (int i = 2; i <= max; i++)
        isPrime.push_back(PRIME);

    for (int divider = 2; divider <= lastNum; divider++)
    {
        if (isPrime[divider - 2] == COMPLEX)
            continue;

        for (int multiple = divider + divider; multiple <= max; multiple += divider)
            isPrime[multiple - 2] = COMPLEX;
    }

    for (int i = min - 2; i < isPrime.size(); i++)
    {
        if (isPrime[i] == PRIME)
            primes.push_back(i + 2);
    }
}

int main()
{
    vector<int> result;
    eratosthenesSieve(2, 200000000, result);
    printResultPrimes(result);
}